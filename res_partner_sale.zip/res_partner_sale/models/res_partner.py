# -*- coding: utf-8 -*-
from odoo import fields, models


class ResPartner(models.Model):
    _inherit = 'res.partner'

    user_id = fields.Many2one('res.users', string='Customer',
                              default=lambda self: self.env.user)
    order_ids = fields.One2many('sale.order',
                                inverse_name='partner_id', string='Sale order')
    sale_count = fields.Integer(compute='_compute_count')

    def _compute_sale_orders(self):
        order_ids = self.env['account.move'].search([('partner_id', '=',
                                                      self.id)])
        for record in order_ids:
            self.order_ids: [(fields.Command.link(record))]

    def _compute_count(self):
        """Invoice count"""
        for rec in self:
            rec.sale_count = (rec.env['sale.order'].search_count(
                [('partner_id', '=', rec.id)]))

    def get_invoices(self):
        """For getting student invoice."""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Sale Count',
            'view_type': 'tree,form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'res_id': self.id,
            'context': {'type': 'out_invoice', 'create': 'True'},
            'domain': [('partner_id', '=', self.id)]
        }